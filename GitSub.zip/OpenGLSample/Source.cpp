﻿#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <GL/glew.h>        // GLEW library
#include <GLFW/glfw3.h>     // GLFW library
#include <map>              // Map Structure

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "meshes.h"
#include "camera.h"

// Image Libraries
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"


/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
	const char* const WINDOW_TITLE = "Christopher Franklin Module 4"; // Window Title

	// Variables for window width and height
	const int WINDOW_WIDTH = 1500;
	const int WINDOW_HEIGHT = 1500;

	// Main GLFW window
	GLFWwindow* gWindow = nullptr;

	// Shader program
	GLuint gObjProgramId;
	GLuint gLightProgramId;

	Meshes meshes;

	// Texture Id
	GLuint gTexture1;
	GLuint gTexture2;
	GLuint gTexture3;
	GLuint gTexture4;
	GLuint gTexture5;
	GLuint gTexture6;
	GLuint gTexture7;
	GLuint gTexture8;
	GLuint gTexture9;
	GLuint gTexture10;
	GLuint gTexture11;
	GLuint gTexture12;
	GLuint gTexture13;

	// Camera
	Camera gCamera(glm::vec3(0.0f, 4.0f, 18.0f));
	float gLastX = WINDOW_WIDTH / 2.0f;
	float gLastY = WINDOW_HEIGHT / 2.0f;
	bool gFirstMouse = true;

	// Variables for Camera Speed
	float gDeltaTime = 0.0f;
	float gLastFrame = 0.0f;
	float cameraSpeed = 2.5f;

	// bool to toggle between views
	bool viewToggle = true;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], GLFWwindow** window);
void UResizeWindow(GLFWwindow* window, int width, int height);
void UProcessInput(GLFWwindow* window);
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void flipImageVertically(unsigned char* image, int width, int height, int channels);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);
bool UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);


/* Vertex Shader Source Code*/
const GLchar* objVertexShaderSource = GLSL(440,
	layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
	layout(location = 1) in vec3 normal; // VAP position 1 for normals
	layout(location = 2) in vec2 textureCoordinate; // Texture data from Vertex Attrib Pointer 2

	out vec3 vertexNormal;
	out vec3 vertexFragmentPos;
	out vec2 vertexTextureCoordinate;

	//Global variables for the transformation
	uniform mat4 model;
	uniform mat4 view;
	uniform mat4 projection;

	void main()
	{
		gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to coordinates

		vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

		vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
		vertexTextureCoordinate = textureCoordinate;
	}
);


//Fragment Shader
const GLchar* objFragmentShaderSource = GLSL(440,

	in vec3 vertexNormal; // For incoming normals
	in vec3 vertexFragmentPos; // For incoming fragment position
	in vec2 vertexTextureCoordinate;

	out vec4 fragmentColor; // For outgoing color to the GPU

	// Uniform / Global variables for object color, light color, light position, and camera/view position
	uniform vec4 objectColor;
	uniform vec3 ambientColor;
	uniform vec3 light1Color;
	uniform vec3 light1Position;
	uniform vec3 light2Color;
	uniform vec3 light2Position;
	uniform vec3 viewPosition;
	uniform sampler2D uTextureBase;
	uniform sampler2D uTextureExtra;
	uniform bool multipleTextures;
	uniform bool ubHasTexture;
	uniform float ambientStrength = 0.1f;
	uniform float specularIntensity1 = 0.1f;
	uniform float highlightSize1 = 16.0f;
	uniform float specularIntensity2 = 0.1f;
	uniform float highlightSize2 = 16.0f;

	void main()
	{
		// Phong lighting model calculations to generate ambient, diffuse, and specular components

		// Calculate Ambient lighting
		vec3 ambient = ambientStrength * ambientColor; // Generate ambient light color

		// Calculate Diffuse lighting
		vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
		vec3 light1Direction = normalize(light1Position - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
		float impact1 = max(dot(norm, light1Direction), 0.0);// Calculate diffuse impact by generating dot product of normal and light
		vec3 diffuse1 = impact1 * light1Color; // Generate diffuse light color
		vec3 light2Direction = normalize(light2Position - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
		float impact2 = max(dot(norm, light2Direction), 0.0);// Calculate diffuse impact by generating dot product of normal and light
		vec3 diffuse2 = impact2 * light2Color; // Generate diffuse light color

		// Calculate Specular lighting
		vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
		vec3 reflectDir1 = reflect(-light1Direction, norm);// Calculate reflection vector
		// Calculate specular component
		float specularComponent1 = pow(max(dot(viewDir, reflectDir1), 0.0), highlightSize1);
		vec3 specular1 = specularIntensity1 * specularComponent1 * light1Color;
		vec3 reflectDir2 = reflect(-light2Direction, norm);// Calculate reflection vector
		// Calculate specular component
		float specularComponent2 = pow(max(dot(viewDir, reflectDir2), 0.0), highlightSize2);
		vec3 specular2 = specularIntensity2 * specularComponent2 * light2Color;

		// Calculate phong result
		// Texture holds the color to be used for all three components
		vec4 textureColor = texture(uTextureBase, vertexTextureCoordinate);
		if (multipleTextures) {
			vec4 extraTexture = texture(uTextureExtra, vertexTextureCoordinate);
			if (extraTexture.a != 0.0) {
				textureColor = extraTexture;
			}
		}
		vec3 phong1;
		vec3 phong2;

		if (ubHasTexture == true)
		{
			phong1 = (ambient + diffuse1 + specular1) * textureColor.xyz;
			phong2 = (ambient + diffuse2 + specular2) * textureColor.xyz;
		}
		else
		{
			phong1 = (ambient + diffuse1 + specular1) * objectColor.xyz;
			phong2 = (ambient + diffuse2 + specular2) * objectColor.xyz;
		}

		fragmentColor = vec4(phong1 + phong2, 1.0); // Send lighting results to GPU
	}
);

// Light Shader Source
const GLchar* lightVertexShaderSource = GLSL(440,

	layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

// Global variables for the  transform matrices
uniform mat4 model;
uniform mat4 view;
uniform mat4 projection;

void main()
{
	gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
);

// Light Fragment Shader Source
const GLchar* lightFragmentShaderSource = GLSL(440,

	out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

void main()
{
	fragmentColor = vec4(1.0f);
}
);


int main(int argc, char* argv[])
{
	if (!UInitialize(argc, argv, &gWindow))
		return EXIT_FAILURE;
	
	// Create the meshes
	meshes.CreateMeshes();

	// Create the shader program
	if (!UCreateShaderProgram(objVertexShaderSource, objFragmentShaderSource, gObjProgramId))
		return EXIT_FAILURE;

	if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightProgramId))
		return EXIT_FAILURE;

	// Load Texture
	const char* texFileName1 = "resources/textures/lABEL.png";
	if (!UCreateTexture(texFileName1, gTexture1)) {

		std::cerr << "Texture Load Failure " << texFileName1 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName2 = "resources/textures/metal.png";
	if (!UCreateTexture(texFileName2, gTexture2)) {

		std::cerr << "Texture Load Failure " << texFileName2 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName3 = "resources/textures/wood.png";
	if (!UCreateTexture(texFileName3, gTexture3)) {

		std::cerr << "Texture Load Failure " << texFileName3 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName4 = "resources/textures/blackrubber.png";
	if (!UCreateTexture(texFileName4, gTexture4)) {

		std::cerr << "Texture Load Failure " << texFileName4 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName5 = "resources/textures/paper.png";
	if (!UCreateTexture(texFileName5, gTexture5)) {

		std::cerr << "Texture Load Failure " << texFileName5 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName6 = "resources/textures/paperbind.png";
	if (!UCreateTexture(texFileName6, gTexture6)) {

		std::cerr << "Texture Load Failure " << texFileName6 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName7 = "resources/textures/pencil.png";
	if (!UCreateTexture(texFileName7, gTexture7)) {

		std::cerr << "Texture Load Failure " << texFileName7 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName8 = "resources/textures/penciltip.png";
	if (!UCreateTexture(texFileName8, gTexture8)) {

		std::cerr << "Texture Load Failure " << texFileName8 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName9 = "resources/textures/metaltip.png";
	if (!UCreateTexture(texFileName9, gTexture9)) {

		std::cerr << "Texture Load Failure " << texFileName9 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName10 = "resources/textures/eraser.png";
	if (!UCreateTexture(texFileName10, gTexture10)) {

		std::cerr << "Texture Load Failure " << texFileName10 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName11 = "resources/textures/transparent.png";
	if (!UCreateTexture(texFileName11, gTexture11)) {

		std::cerr << "Texture Load Failure " << texFileName11 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName12 = "resources/textures/erasersleeve.png";
	if (!UCreateTexture(texFileName12, gTexture12)) {

		std::cerr << "Texture Load Failure " << texFileName12 << std::endl;
		return EXIT_FAILURE;
	}

	const char* texFileName13 = "resources/textures/Gold.png";
	if (!UCreateTexture(texFileName13, gTexture13)) {

		std::cerr << "Texture Load Failure " << texFileName13 << std::endl;
		return EXIT_FAILURE;
	}

	glUseProgram(gObjProgramId);
	glUniform1i(glGetUniformLocation(gObjProgramId, "uTextureBase"), 0);
	glUniform1i(glGetUniformLocation(gObjProgramId, "uTextureExtra"), 1);

	// Sets the background color of the window to black 
	glClearColor(0.0f, 0.0f, 0.0f, 1.0f);

	// render loop
	while (!glfwWindowShouldClose(gWindow))
	{
		// Timing
		float currentFrame = glfwGetTime();
		gDeltaTime = currentFrame - gLastFrame;
		gLastFrame = currentFrame;

		// Input
		UProcessInput(gWindow);

		URender();

		glfwPollEvents();
	}

	// Destroy Mesh
	meshes.DestroyMeshes();

	// Destroy Texture Data
	UDestroyTexture(gTexture1);
	UDestroyTexture(gTexture2);
	UDestroyTexture(gTexture3);
	UDestroyTexture(gTexture4);

	// Destroy Shader
	UDestroyShaderProgram(gObjProgramId);
	UDestroyShaderProgram(gLightProgramId);

	exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
	// GLFW: initialize and configure
	// ------------------------------
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	// Create Window
	* window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
	if (*window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return false;
	}
	glfwMakeContextCurrent(*window);
	glfwSetFramebufferSizeCallback(*window, UResizeWindow);

	// Initialize
	GLenum GlewInitResult = glewInit();

	if (GLEW_OK != GlewInitResult)
	{
		std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
		return false;
	}

	// Displays GPU OpenGL version
	std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;

	// Mouse Callbacks
	glfwSetCursorPosCallback(*window, UMousePositionCallback);
	glfwSetScrollCallback(*window, UMouseScrollCallback);

	// Captures Mouse
	glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

	// Enable Blending
	glEnable(GL_BLEND);
	glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);

	return true;
}


// Process Input Data
void UProcessInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {

		glfwSetWindowShouldClose(window, true);
	}
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS) {

		glfwSetWindowShouldClose(window, true);
	}
	if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS) {

		if (viewToggle == true) {
			gCamera.ProcessKeyboard(FORWARD, gDeltaTime, cameraSpeed);
		}
	}
	if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS) {

		if (viewToggle == true) {
			gCamera.ProcessKeyboard(BACKWARD, gDeltaTime, cameraSpeed);
		}
	}
	if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS) {

		gCamera.ProcessKeyboard(LEFT, gDeltaTime, cameraSpeed);
	}
	if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS) {

		gCamera.ProcessKeyboard(RIGHT, gDeltaTime, cameraSpeed);
	}
	if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS) {

		gCamera.ProcessKeyboard(UP, gDeltaTime, cameraSpeed);
	}
	if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS) {

		gCamera.ProcessKeyboard(DOWN, gDeltaTime, cameraSpeed);
	}

	if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS) {
		viewToggle = true;
		gCamera.Position = glm::vec3(0.0f, 4.0f, 18.0f);
		gCamera.Front = glm::vec3(0.0f, 0.0f, -2.0f);
		gCamera.Up = glm::vec3(0.0f, 1.0f, 0.0f);
	}

	if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS) {
		viewToggle = false;
		gCamera.Position = glm::vec3(0.0f, 0.5f, 12.0f);
		gCamera.Front = glm::vec3(0.0f, 0.0f, -2.0f);
		gCamera.Up = glm::vec3(0.0f, 1.0f, 0.0f);
	}
}

// Calls Mouse Position
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
	if (gFirstMouse) {

		gLastX = xpos;
		gLastY = ypos;
		gFirstMouse = false;
	}

	float xoffset = xpos - gLastX;
	float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

	gLastX = xpos;
	gLastY = ypos;

	if (viewToggle == true) {
		gCamera.ProcessMouseMovement(xoffset, yoffset);
	}
}

// Calls Mouse Scroll Wheel to Control cameraSpeed
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset) {

	if (yoffset > 0) {
		cameraSpeed += 1.0;
	}
	if (yoffset < 0) {
		if (cameraSpeed == 0.0) {
			cameraSpeed = 0.0;
		}
		else if (cameraSpeed > 1.0) {
			cameraSpeed -= 1.0;
		}

	}
}

// Flips Image
void flipImageVertically(unsigned char* image, int width, int height, int channels) {

	for (int j = 0; j < height / 2; ++j) {

		int index1 = j * width * channels;
		int index2 = (height - 1 - j) * width * channels;

		for (int i = width * channels; i > 0; --i) {

			unsigned char tmp = image[index1];
			image[index1] = image[index2];
			image[index2] = tmp;
			++index1;
			++index2;
		}
	}
}

// Resizes window when changed
void UResizeWindow(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// Frame Rendering Function
void URender()
{
	glm::mat4 scale;
	glm::mat4 rotation;
	glm::mat4 rotation1;
	glm::mat4 rotation2;
	glm::mat4 rotation3;
	glm::mat4 translation;
	glm::mat4 model;
	glm::mat4 view;
	glm::mat4 projection;
	GLint viewPosLoc;
	GLint ambStrLoc;
	GLint ambColLoc;
	GLint light1ColLoc;
	GLint light1PosLoc;
	GLint light2ColLoc;
	GLint light2PosLoc;
	GLint objColLoc;
	GLint specInt1Loc;
	GLint highlghtSz1Loc;
	GLint specInt2Loc;
	GLint highlghtSz2Loc;
	GLint uHasTextureLoc;
	bool ubHasTextureVal;
	GLint modelLoc;
	GLint viewLoc;
	GLint projLoc;
	GLint objectColorLoc;
	bool multipleTextures = false;

	if (viewToggle == true) {
		projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 0.1f, 100.0f);
	}
	else {
		projection = glm::ortho(-5.0f, 0.0f, -5.0f, 5.0f, 0.1f, 100.0f);
	}

	// Enable Z-depth
	glEnable(GL_DEPTH_TEST);

	// Clear the frame and Z buffers
	glClearColor(0.0f, 0.4f, 0.6f, 1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// View Matrix
	view = gCamera.GetViewMatrix();

	// Set the shader
	glUseProgram(gObjProgramId);

	// Retrieves and passes transform matrices to the Shader program
	modelLoc = glGetUniformLocation(gObjProgramId, "model");
	viewLoc = glGetUniformLocation(gObjProgramId, "view");
	projLoc = glGetUniformLocation(gObjProgramId, "projection");
	viewPosLoc = glGetUniformLocation(gObjProgramId, "viewPosition");
	ambStrLoc = glGetUniformLocation(gObjProgramId, "ambientStrength");
	ambColLoc = glGetUniformLocation(gObjProgramId, "ambientColor");
	light1ColLoc = glGetUniformLocation(gObjProgramId, "light1Color");
	light1PosLoc = glGetUniformLocation(gObjProgramId, "light1Position");
	light2ColLoc = glGetUniformLocation(gObjProgramId, "light2Color");
	light2PosLoc = glGetUniformLocation(gObjProgramId, "light2Position");
	objColLoc = glGetUniformLocation(gObjProgramId, "objectColor");
	specInt1Loc = glGetUniformLocation(gObjProgramId, "specularIntensity1");
	highlghtSz1Loc = glGetUniformLocation(gObjProgramId, "highlightSize1");
	specInt2Loc = glGetUniformLocation(gObjProgramId, "specularIntensity2");
	highlghtSz2Loc = glGetUniformLocation(gObjProgramId, "highlightSize2");
	uHasTextureLoc = glGetUniformLocation(gObjProgramId, "ubHasTexture");

	// Pass transformations to shader
	modelLoc = glGetUniformLocation(gObjProgramId, "model");
	viewLoc = glGetUniformLocation(gObjProgramId, "view");
	projLoc = glGetUniformLocation(gObjProgramId, "projection");
	objectColorLoc = glGetUniformLocation(gObjProgramId, "uObjectColor");

	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	// Set Camera View
	glUniform3f(viewPosLoc, gCamera.Position.x, gCamera.Position.y, gCamera.Position.z);

	// Set Ambient Lighting Strength
	glUniform1f(ambStrLoc, 0.4f);

	// Set Ambient Color
	glUniform3f(ambColLoc, 0.1f, 0.1f, 0.1f);
	glUniform3f(light1ColLoc, 1.0f, 0.961f, 0.729f);
	glUniform3f(light1PosLoc, -3.4f, 10.0f, 1.5f);
	glUniform3f(light2ColLoc, 1.0f, 1.0f, 1.0f);
	glUniform3f(light2PosLoc, 3.0f, 20.0f, -3.0f);

	// Set Specular Intensity
	glUniform1f(specInt1Loc, -1.5f);
	glUniform1f(specInt2Loc, 0.2f);

	// Set Specular Highlight Size
	glUniform1f(highlghtSz1Loc, 2.0f);
	glUniform1f(highlghtSz2Loc, 2.0f);

	ubHasTextureVal = true;
	glUniform1i(uHasTextureLoc, ubHasTextureVal);

	GLuint multipleTexturesLoc = glGetUniformLocation(gObjProgramId, "multipleTextures");

	// Plane Object for Desk
	// Activate VBOs
	glActiveTexture(GL_TEXTURE0);
	glBindVertexArray(meshes.gPlaneMesh.vao);
	glBindTexture(GL_TEXTURE_2D, gTexture3);

	// Transformations
	scale = glm::scale(glm::vec3(15.0f, 1.0f, 15.0f));
	rotation = glm::rotate(0.0f, glm::vec3(1.0, 1.0f, 1.0f));
	translation = glm::translate(glm::vec3(0.0f, 0.5f, 0.0f));
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.8f, 0.6f, 0.5f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gPlaneMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Middle object in stamp	
	// Activate the VBOs
	glBindVertexArray(meshes.gBoxMesh.vao);

	// Bind Textures
	multipleTextures = true;
	glUniform1i(multipleTexturesLoc, multipleTextures);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture2);
	glActiveTexture(GL_TEXTURE1);
	glBindTexture(GL_TEXTURE_2D, gTexture1);

	// Transformations
	scale = glm::scale(glm::vec3(4.0f, 1.0f, 1.0f));
	rotation = glm::rotate(45.0f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(2.0f, 1.9f, -1.0f));
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.4f, 1.0f, 0.2f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);
	glBindTexture(GL_TEXTURE_2D,NULL);
	multipleTextures = false;
	glUniform1i(multipleTexturesLoc, multipleTextures);

	// Top of the stamp
	// Activate the VBOs
	glBindVertexArray(meshes.gCylinderMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture2);

	// Transformations
	scale = glm::scale(glm::vec3(0.32f, 3.999f, 0.501f));
	rotation1 = glm::rotate(0.0f, glm::vec3(1.0f, 0.0f, 0.0f));
	rotation2 = glm::rotate(2.124f, glm::vec3(0.0f, 1.0f, 0.0f));
	rotation3 = glm::rotate(1.57f, glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(glm::vec3(0.948f, 2.38f, -2.701f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	// Draw
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	//NotePad
	// Main Cube for paper
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture5);

	//Transformations
	scale = glm::scale(glm::vec3(7.0f, 0.2f, 9.0f));
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(-1.8f, 0.61f, 6.0f));
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Small Cube for Binding
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture6);

	//Transformations
	scale = glm::scale(glm::vec3(7.0f, 0.2f, 0.5f));
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(-1.8f, 0.61f, 1.25f));
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Pencil
	// Body of Pencil
	// Activate the VBOs
	glBindVertexArray(meshes.gCylinderMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture7);

	// Transformations
	scale = glm::scale(glm::vec3(0.1f, 3.999f, 0.1f));
	rotation1 = glm::rotate(1.5708f, glm::vec3(1.0f, 0.0f, 0.0f));
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.785398f, glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(glm::vec3(0.955f, 0.81f, 6.0f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	// Draw
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Pencil
	// Pencil Tip
	glBindVertexArray(meshes.gConeMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture8);

	scale = glm::scale(glm::vec3(0.1f, 0.5f, 0.1f));
	rotation1 = glm::rotate(1.5708f, glm::vec3(1.0, 0.0f, 0.0f));
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.785398f, glm::vec3(0.0, 0.0f, 1.0f));
	translation = glm::translate(glm::vec3(-1.873f, 0.81f, 8.828f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 1.0f, 1.0f);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_STRIP, 36, 108);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Pencil
	// Metal Top of Pencil
	// Activate the VBOs
	glBindVertexArray(meshes.gCylinderMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture9);

	// Transformations
	scale = glm::scale(glm::vec3(0.1f, 0.27f, 0.1f));
	rotation1 = glm::rotate(1.5708f, glm::vec3(1.0f, 0.0f, 0.0f));
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.785398f, glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(glm::vec3(1.147f, 0.81f, 5.809f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	// Draw
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Pencil
	// Eraser on top of Pencil
	// Activate the VBOs
	glBindVertexArray(meshes.gCylinderMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture10);

	// Transformations
	scale = glm::scale(glm::vec3(0.1f, 0.15f, 0.1f));
	rotation1 = glm::rotate(1.5708f, glm::vec3(1.0f, 0.0f, 0.0f));
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.785398f, glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(glm::vec3(1.253f, 0.81f, 5.703f));//81
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	// Draw
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Eraser Body
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture10);

	//Transformations
	scale = glm::scale(glm::vec3(1.4f, 0.3f, 0.8f));
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(-1.8f, 0.86f, 5.25f));//0.61
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Eraser Sleeve
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture12);

	//Transformations
	scale = glm::scale(glm::vec3(1.0f, 0.301f, 0.801f));
	rotation = glm::rotate(0.0f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(-1.61f, 0.86f, 5.25f));//0.61
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Base of Lamp
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture4);

	//Transformations
	scale = glm::scale(glm::vec3(5.0f, 0.3f, 3.5f));
	rotation = glm::rotate(0.785398f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(-7.0f, 0.86f, -3.0f));//0.61
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Lamp Upright
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture13);

	//Transformations
	scale = glm::scale(glm::vec3(0.5f, 9.92f, 0.5f));
	rotation = glm::rotate(0.785398f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(-7.0f, 5.9f, -3.0f));//0.61
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Lamp Horizontal
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture13);

	//Transformations
	scale = glm::scale(glm::vec3(3.0f, 0.5f, 0.5f));
	rotation = glm::rotate(0.785398f, glm::vec3(0.0f, -1.0f, 0.0f));//0.785398
	translation = glm::translate(glm::vec3(-6.0f, 10.61f, -2.0f));
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Lamp Angle
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture13);

	//Transformations
	scale = glm::scale(glm::vec3(2.0f, 0.5f, 0.5f));
	rotation1 = glm::rotate(0.785398f, glm::vec3(0.0f, -1.0f, 0.0f));//0.785398
	rotation2 = glm::rotate(0.6f, glm::vec3(0.0f, 0.0f, -1.0f));
	translation = glm::translate(glm::vec3(-4.45530f, 10.0891f, -0.45530f));
	model = translation * rotation1 * rotation2 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Light Cone
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gConeMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture13);

	scale = glm::scale(glm::vec3(2.0f, 3.0f, 2.0f));
	rotation1 = glm::rotate(0.78f, glm::vec3(-1.0, 0.0f, 0.0f));//1.5708
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.6f, glm::vec3(0.0, 0.0f, 1.0f));//0.785398
	translation = glm::translate(glm::vec3(-3.0f, 10.0f, 1.0f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 1.0f, 1.0f);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_STRIP, 36, 108);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Knob 1
	// Activate the VBOs
	glBindVertexArray(meshes.gCylinderMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture4);

	// Transformations
	scale = glm::scale(glm::vec3(0.3f, 0.6f, 0.3f));
	rotation1 = glm::rotate(0.9f, glm::vec3(-1.0f, 0.0f, 0.0f)); //1.5708
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.7f, glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(glm::vec3(-4.35f, 11.44f, -0.4f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	// Draw
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Knob 2
	// Activate the VBOs
	glBindVertexArray(meshes.gCylinderMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture4);

	// Transformations
	scale = glm::scale(glm::vec3(0.07f, 0.75f, 0.07f));
	rotation1 = glm::rotate(0.9f, glm::vec3(-1.0f, 0.0f, 0.0f)); //1.5708
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0f, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.7f, glm::vec3(0.0f, 0.0f, 1.0f));
	translation = glm::translate(glm::vec3(-4.35f, 11.44f, -0.4f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 0.0f, 1.0f);

	// Draw
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_FAN, 36, 36);		//top
	glDrawArrays(GL_TRIANGLE_STRIP, 72, 146);	//sides

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Bottom of Stamp
	// Activate the VBOs contained within the mesh's VAO
	glBindVertexArray(meshes.gBoxMesh.vao);
	glActiveTexture(GL_TEXTURE0);

	float color[] = { 1.0f, 0.0f, 1.0f, 1.0f };
	glTexParameterfv(GL_TEXTURE_2D, GL_TEXTURE_BORDER_COLOR, color);
	glBindTexture(GL_TEXTURE_2D, gTexture11);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_BORDER);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_BORDER);

	//Transformations
	scale = glm::scale(glm::vec3(3.9f, 0.9f, 0.9f));
	rotation = glm::rotate(45.0f, glm::vec3(0.0f, -1.0f, 0.0f));
	translation = glm::translate(glm::vec3(2.0f, 1.0f, -1.0f));
	model = translation * rotation * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 0.2f, 0.2f, 1.0f, 1.0f);

	// Draw
	glDrawElements(GL_TRIANGLES, meshes.gBoxMesh.nIndices, GL_UNSIGNED_INT, (void*)0);

	// Deactivate the Vertex Array Object
	glBindVertexArray(0);

	// Light Bulb Cone

	glUseProgram(gLightProgramId);

	// Reference matrix uniforms from the Lamp Shader program
	modelLoc = glGetUniformLocation(gLightProgramId, "model");
	viewLoc = glGetUniformLocation(gLightProgramId, "view");
	projLoc = glGetUniformLocation(gLightProgramId, "projection");

	// Pass matrix data to the Lamp Shader program's matrix uniforms
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
	glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
	glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

	glBindVertexArray(meshes.gConeMesh.vao);
	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, gTexture13);

	scale = glm::scale(glm::vec3(1.8f, 1.0f, 1.8f));
	rotation1 = glm::rotate(0.78f, glm::vec3(-1.0, 0.0f, 0.0f));//1.5708
	rotation2 = glm::rotate(0.0f, glm::vec3(0.0, 1.0f, 0.0f));
	rotation3 = glm::rotate(0.6f, glm::vec3(0.0, 0.0f, 1.0f));//0.785398
	translation = glm::translate(glm::vec3(-2.98f, 10.f, 1.0f));
	model = translation * rotation1 * rotation2 * rotation3 * scale;
	glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

	glProgramUniform4f(gObjProgramId, objectColorLoc, 1.0f, 0.0f, 1.0f, 1.0f);

	// Draws the triangles
	glDrawArrays(GL_TRIANGLE_FAN, 0, 36);		//bottom
	glDrawArrays(GL_TRIANGLE_STRIP, 36, 108);	//sides

	// Deactivate the Vertex Array Object and shader program
	glBindVertexArray(0);
	glUseProgram(0);

	// glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
	glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}

// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
	// Error reporting
	int success = 0;
	char infoLog[512];

	// Create a Shader Program Object
	programId = glCreateProgram();

	// Create the vertex and fragment shader objects
	GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
	GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

	// Retrive the shader
	glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
	glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

	// Compile the vertex shader, and print errors
	glCompileShader(vertexShaderId); // compile the vertex shader
	// check for shader compile errors
	glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
		std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glCompileShader(fragmentShaderId); // compile the fragment shader
	// check for shader compile errors
	glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
	if (!success)
	{
		glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

		return false;
	}

	// Attach compiled shaders to the shader program
	glAttachShader(programId, vertexShaderId);
	glAttachShader(programId, fragmentShaderId);

	glLinkProgram(programId);   // link the shader program
	// check for linking errors
	glGetProgramiv(programId, GL_LINK_STATUS, &success);
	if (!success)
	{
		glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
		std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

		return false;
	}

	glUseProgram(programId);    // Uses the shader program

	return true;
}


void UDestroyShaderProgram(GLuint programId)
{
	glDeleteProgram(programId);
}

bool UCreateTexture(const char* filename, GLuint& textureId) {
	int width, height, channels;
	unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
	if (image)
	{
		flipImageVertically(image, width, height, channels);

		glGenTextures(1, &textureId);
		glBindTexture(GL_TEXTURE_2D, textureId);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		if (channels == 3) {

			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		}
		else if (channels == 4) {

			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		}
		else {

			std::cout << "Not implemented to handle image with " << channels << " channels" << std::endl;
			return false;
		}

		glGenerateMipmap(GL_TEXTURE_2D);

		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		return true;
	}

	// Error loading the image
	return false;
}

void UDestroyTexture(GLuint textureId) {

	glGenTextures(1, &textureId);
}
